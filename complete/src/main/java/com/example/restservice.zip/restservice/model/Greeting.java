package com.example.restservice.model;

public record Greeting(long id, String content) {
}
